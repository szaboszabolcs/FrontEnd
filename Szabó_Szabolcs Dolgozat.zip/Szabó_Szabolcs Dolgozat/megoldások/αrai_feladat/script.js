//  Órai feladat

// 2500 Ft -> 1 db 2000-es, 1 db 500-as

let osszeg = Number(prompt("Hány forintot  szeretnél a címletekkel kifizetni?:"));
let cimletek = [20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10 ];
console.log(cimletek);

for (i = 0; i <= cimletek; i++) {
    if (osszeg >= 20000 ) {
        console.log(cimletek[0])
    } 
    else if (osszeg >= 10000 ) {
        console.log(cimletek[1])
    }
}