 // 1) feladat

let elso_szam = Number(window.prompt("Add meg az első számot: "));
let masodik_szam = Number(window.prompt("Add meg a második számot: "));
let harmadik_szam = Number(window.prompt("Add meg a harmadik számot: "));

let max = Math.max(elso_szam, masodik_szam, harmadik_szam);

// 2) feladat
let shape = prompt("Milyen alakzat területét számoljuk? (T =  téglalap, H = háromszög");

if (shape === T || shape === "t"){
    let a = Number(propmt("Add meg a téglalap egyik oldalát: "))
    let b = Number(propmt("Add meg a téglalap egyik oldalát: "))
    let area = a * b;
    alert("A területe: "+area);
    
} else if (shape === H || shape === "h") {
    let a = Number(propmt("Add meg a háromszög egyik oldalát: "));
    let h = Number(propmt("Add meg a háromszög egyik oldalát: "));
    let area = a*h/2;
    alert("A területe: "+area);
} else {
    alert("Rossz adatot adtál meg!")
}

// 3) feladat

let num4 = Number(prompt("Adj meg egy számot:"))
let dividers = [];

for(let i = 1; i <= num4; i++) {
    if (num4 % i == 0) {
    dividers.push(i);
    console.log(i)
    }
}
alert("Az osztók: "+dividers);


// 4) feladat

let numberArray = [1,2,3,4,5];
let stringArray = ["Jan","Feb", "Márc", "Ápr", "Máj"];
let customArray = [];

for (let i = 0; i < numberArray.length; i++) {
    customArray.push(numberArray[i]);
    customArray.push(stringArray[i]);
}

console.log(customArray);

// Prímes feladat

let num4 = Number(prompt("Adj meg egy számot:"))
let primBoolean = true;

for(let i = 2; i <= num4; i++) {
    for (let j = 2; j < i; j++) {
        if (i % j == 0) {
            break;
        }

        console.log(i);
    }
}