/* 1) Kérj be a felhasználótól 3 számot, alertezd ki neki a legnagyobb számot! */

let elso_szam = Number(window.prompt("Add meg az első számot: "));
let masodik_szam = Number(window.prompt("Add meg a második számot: "));
let harmadik_szam = Number(window.prompt("Add meg a harmadik számot: "));

if (elso_szam >= masodik_szam && elso_szam >= harmadik_szam)
        alert(elso_szam+ " a legnagyobb.");
 
    else if (masodik_szam >= elso_szam && masodik_szam >= harmadik_szam)
        alert( masodik_szam + " a legnagyobb.");
 
    else
        alert( harmadik_szam + " a legnagyobb.");
     

 /* 2) Kérdezd meg a felhasználótól, hogy háromszög vagy téglalap területet számoljunk-e? Kérj be tőle 2 adatot (magasság+oldal háromszögnél,
    két oldal téglalapnál), majd írd ki a területet! */

var dontes = Number(window.prompt("Háromszög vagy téglalap területet számoljunk?"));
var haromszog = "háromszög";
var teglalap = "téglalap";

if (dontes = haromszog)
{
    const alap = prompt('Adja meg egy háromszög alapját:');
    const magassag = prompt('Adja meg a háromszög magasságát:');

    const terulet_1 = (alap * magassag) / 2;

    alert(`A háromszög területe:  ${terulet_1}`)

} else if (dontes = teglalap) {

    var a_oldal = parseInt(prompt("Adja meg a téglalap 'a' oldalát:"));
    var b_oldal = parseInt(prompt("Adja meg a téglalap 'b' oldalát:"));
    var terulet = a_oldal * b_oldal ;
    alert("A téglalap területe: " + terület);
}


 /* 3) Osztókeresés: Kérj be egy egyjegyű számot és írd ki az egész pozitív osztóit! */
var num = prompt("Adjon meg egy egyjegyű számot: ")

console.log(` ${num} Ennek a számnak az osztói:`);

for(let i = 1; i <= num; i++) {
    if(num % i == 0) {
        console.log(i);
    }
}



/* 4) Tömbösszefűzés: Tölts fel 2 tömböt adatokkal, és fűzd össze őket 1 tömbbe úgy, hogy változzanak az adatok.
pl.  [1,2,3] [A,B,C]  [1,A,2,B,3,C] */

var tomb_1 = [1,2,3]
var tomb_2 = ["A","B","C"]
const tomb_3 = tomb_1.concat(tomb_2);
console.log(tomb_3)

