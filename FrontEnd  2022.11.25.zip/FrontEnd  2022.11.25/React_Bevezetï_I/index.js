// Natív //

const gomb1 = document.createElement("button");
gomb1.innerHTML = "Gomb";
gomb1.onclick = function() {
    alert("Hello");
}
document.querySelector("#gomb1").appendChild(gomb1);

// Natív vége //


//React.createElement(mit?, milyen jellemzőkkel, gyermekelemek)

const gomb2 = React.createElement("button",{
    onClick: function() {
        alert("Hello React!");
    }
},"Gomb2")

ReactDOM.render(gomb2,document.querySelector("#react-gomb2"))


//ReactDOM.render(hova?); 

ReactDOM.render(React.createElement(App),document.querySelector("#react-app-container"))

function App() {
    //state be van e nyomva
    return React.createElement("div",{},"App",
    React.createElement(BoxComponent, {hatterSzin: "green", szoveg: "Hello React."}),
    React.createElement(BoxComponent, {hatterSzin: "red", szoveg: 2}),
    React.createElement(BoxComponent, {hatterSzin: "blue", szoveg: 3}),
    )
}

function BoxComponent(props) {
    //state change
    const [getState, setState] = React.useState(0)
    console.log(props)
    return React.createElement("div",{
        style: {
            width: "200px",
            height: "200px",
            backgroundColor: props.hatterSzin,
            margin: "10px"
        },

        onClick: () => {
            setState(getState => getState + 1)
        }
    },React.createElement("h1",{},getState)

    )
}


/*

//JSX
ReactDOM.render(<div style="width: 200px, height: 200px, background-color: props.hatterSzin, margin: 5px">
Box 
</div>,document.querySelector("#react-app-container"));

*/