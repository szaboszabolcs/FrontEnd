var dog = document.getElementById("dogPic");

var moving = false;

dog.addEventListener("mousedown", initialClick, false);



function move(e){

  var newX = e.clientX - 10;
  var newY = e.clientY - 10;

  image.style.left = newX + "px";
  image.style.top = newY + "px";

  
}

function initialClick(e) {

  if(moving){
    document.removeEventListener("mousemove", move);
    moving = !moving;
    return;
  }
  
  moving = !moving;
  image = this;

  document.addEventListener("mousemove", move, false);

}


// Másik megoldás //

let state = {
    x: 0,
    y: 0,
    isDragged: false
}

window.onload = move;


function move() {

    const kep = `
    <img
        src="img.gif"
        style="width: 200px; height: auto; position: absolute; left: ${state.x}px; top: ${state.y}px;"
        class=${state.isDragged ? "grabbed" : "not-grabbed"}
        onmousedown= "imgDragStart()"
        onmouseup = "imgDragStop()"
        onmousemove = "imgMouseMove(event)"
        >
    </img>
    `
    document.body.innerHTML = kep;

}

function imgDragStart() {
    console.log("1");
    state.isDragged = true;
    move()
    
}

function imgDragStop() {
    console.log("2");
    state.isDragged = false;
    move()
    
}

function imgMouseMove(event) {
    console.log("3");
    if (state.isDragged) {
        const picture = event.target;
        state.x = event.clientX - picture.offsetWidth / 2;
        state.y = event.clientY - picture.offsetHeight / 2;
    move();
    }
}