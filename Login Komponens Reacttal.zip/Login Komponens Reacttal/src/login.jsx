/*
    Login url: https://reqres.in/api/login
    Body:
    {
      email: "eve.holt@reqres.in",
      password: "ok"
    }
    Users url: https://reqres.in/api/users
*/

ReactDOM.render(<App/>,document.querySelector("#login-component"));

function App()
{
    const [isPending, setPending] = React.useState(false);  // Folyamatban van-e a bejelentkezés //
    const [list, setList] = React.useState([]); // lista akik szereplenek az adatbázisban //
    const [isSubmit, setSubmit] = React.useState(false); 
    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");

    // React. useEffect(függvény, [mivaltozzon])
    React.useEffect(() =>
    {
        if (isSubmit)
        {
            let body =
            {
                email: email,
                password: password
            };

            axios.post("https://localhost:5001/Versenyzok", body)
            .then((response) => axios.get("https://localhost:5001/Versenyzok"))
            .then((response) =>
            {
              console.log(response);
                setList(response.data.data);
                setPending(false);
                setSubmit(false);
            })
            .catch((error) =>
            {
              setPending(false);
              setSubmit(false);
              alert("Bejelentkezés sikertelen");
            })
        }
    }, [isSubmit]);

    return <div className="border">
    <FormComponent isPending={isPending} setPending={setPending} setSubmit={setSubmit}
    setEmail={setEmail} setPassword={setPassword}/>
    <ListComponent list={list}/>
    <button onClick={() => 
    {
        if (isClicked)
        {
        axios.get("https://localhost:5001/Versenyzok")
            .then((response) =>
            {
              console.log(response);
                setList(response.data.data);
                setPending(false);
                setSubmit(false);
            })
            .catch((error) =>
            {
              setPending(false);
              setSubmit(false);
              alert("Bejelentkezés sikertelen");
            })
        }
    }, [isSubmit]);
    }}>Get</button>
    </div>  
}

function FormComponent({isPending, setPending, setSubmit, setEmail, setPassword}) {
    return <div class="card p-3">    
    <h1>Bejelentkezés</h1>   
    <form id="login" class="p-3" onSubmit={(event) =>
    {
        event.preventDefault();
        setEmail(event.target.elements.email.value);
        setPassword(event.target.elements.password.value);
        setSubmit(true);
        setPending(true);

    }}>
      <label class="w-100">
        Email:
        <input type="text" name="email" class="form-control" disabled={isPending}/>
      </label>
      <label class="w-100">
        Jelszó:
        <input type="password" name="password" class="form-control" disabled={isPending}/>
      </label>
      <button type="submit" class="btn btn-primary" disabled={isPending}>
        Küldés
        </button>
      <div id="message" class="float-right mt-2">
        {isPending ? "Bejelentkezés folyamatban..." : ""}
      </div>
    </form>
  </div>
}

function ListComponent({list})
{
    return <ul>
    {list.map((item) =>
    (
      <li key={item.id} className="list-group-item">{item.email}</li>
    ))}
  </ul>
}