var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

/*
    Login url: https://reqres.in/api/login
    Body:
    {
      email: "eve.holt@reqres.in",
      password: "ok"
    }
    Users url: https://reqres.in/api/users
*/

ReactDOM.render(React.createElement(App, null), document.querySelector("#login-component"));

function App() {
  var _React$useState = React.useState(false),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      isPending = _React$useState2[0],
      setPending = _React$useState2[1]; // Folyamatban van-e a bejelentkezés //


  var _React$useState3 = React.useState([]),
      _React$useState4 = _slicedToArray(_React$useState3, 2),
      list = _React$useState4[0],
      setList = _React$useState4[1]; // lista akik szereplenek az adatbázisban //


  var _React$useState5 = React.useState(false),
      _React$useState6 = _slicedToArray(_React$useState5, 2),
      isSubmit = _React$useState6[0],
      setSubmit = _React$useState6[1];

  var _React$useState7 = React.useState(""),
      _React$useState8 = _slicedToArray(_React$useState7, 2),
      email = _React$useState8[0],
      setEmail = _React$useState8[1];

  var _React$useState9 = React.useState(""),
      _React$useState10 = _slicedToArray(_React$useState9, 2),
      password = _React$useState10[0],
      setPassword = _React$useState10[1];

  // React. useEffect(függvény, [mivaltozzon])


  React.useEffect(function () {
    if (isSubmit) {
      var body = {
        email: email,
        password: password
      };

      axios.post("https://localhost:5001/Versenyzok", body).then(function (response) {
        return axios.get("https://localhost:5001/Versenyzok");
      }).then(function (response) {
        console.log(response);
        setList(response.data.data);
        setPending(false);
        setSubmit(false);
      }).catch(function (error) {
        setPending(false);
        setSubmit(false);
        alert("Bejelentkezés sikertelen");
      });
    }
  }, [isSubmit]);

  return React.createElement(
    "div",
    { className: "border" },
    React.createElement(FormComponent, { isPending: isPending, setPending: setPending, setSubmit: setSubmit,
      setEmail: setEmail, setPassword: setPassword }),
    React.createElement(ListComponent, { list: list }),
    React.createElement(
      "button",
      { onClick: function onClick() {} },
      "Get"
    )
  );
}

function FormComponent(_ref) {
  var isPending = _ref.isPending,
      setPending = _ref.setPending,
      setSubmit = _ref.setSubmit,
      setEmail = _ref.setEmail,
      setPassword = _ref.setPassword;

  return React.createElement(
    "div",
    { "class": "card p-3" },
    React.createElement(
      "h1",
      null,
      "Bejelentkez\xE9s"
    ),
    React.createElement(
      "form",
      { id: "login", "class": "p-3", onSubmit: function onSubmit(event) {
          event.preventDefault();
          setEmail(event.target.elements.email.value);
          setPassword(event.target.elements.password.value);
          setSubmit(true);
          setPending(true);
        } },
      React.createElement(
        "label",
        { "class": "w-100" },
        "Email:",
        React.createElement("input", { type: "text", name: "email", "class": "form-control", disabled: isPending })
      ),
      React.createElement(
        "label",
        { "class": "w-100" },
        "Jelsz\xF3:",
        React.createElement("input", { type: "password", name: "password", "class": "form-control", disabled: isPending })
      ),
      React.createElement(
        "button",
        { type: "submit", "class": "btn btn-primary", disabled: isPending },
        "K\xFCld\xE9s"
      ),
      React.createElement(
        "div",
        { id: "message", "class": "float-right mt-2" },
        isPending ? "Bejelentkezés folyamatban..." : ""
      )
    )
  );
}

function ListComponent(_ref2) {
  var list = _ref2.list;

  return React.createElement(
    "ul",
    null,
    list.map(function (item) {
      return React.createElement(
        "li",
        { key: item.id, className: "list-group-item" },
        item.email
      );
    })
  );
}