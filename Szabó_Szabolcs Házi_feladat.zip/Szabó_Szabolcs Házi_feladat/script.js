/* Kérj be egy számot a felhasználótól! Írasd ki konzolba az összes primszámot addig a számig!
A program számolja ki, hogy valami primszám-e vagy sem, ne te sorold fel. 
Könnyítés, hogy az 1-es számot nem kell belevenni a vizsgálatba. */


var szam = Number(prompt("Adj meg egy pozitív egész számot: "))
  
// Függvény segítségével ellenőrizem, hogy a szám prímszám-e.
function isPrime( n)
{
      // A 0 és az 1 nem prímszám ezért a visszatérési érték hamis.
      if(n == 1 || n == 0) return false;
    
      // For ciklus 2- től az n-ig.
      for(var i = 2; i < n; i++)
      {
        
        // Ha a szám osztható i-vel, akkor n nem prímszám.
        if(n % i == 0) return false;
      }
      // más esetben n prímszám
      return true;
}
  
var N = szam;
  
// A for ciklus minden számot ellenőriz 1 től N-ig.
  for(var i = 1; i <= szam; i++)
  {
      // ellenőrzés, hogy az aktuális szám prímszám-e
      if(isPrime(i)) {
        console.log( i );
      }
}