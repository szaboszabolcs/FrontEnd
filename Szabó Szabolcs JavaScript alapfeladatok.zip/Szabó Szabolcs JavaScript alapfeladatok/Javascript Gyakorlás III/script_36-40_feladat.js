/* 36. feladat
írj programot, mely beolvassa a hatvány alapját és a kitevőt, és kiírja a hatványértéket!*/

var b = prompt("Adjon meg egy hatvány alapot: ");
var n = propmt("Adjon meg egy kitevőt: ")
function exp(b,n)
{
        var ans = 1;
        for (var i =1; i <= n; i++)
        {
                ans = b * ans;        
        }
        return ans;
}
alert(exp(b,n));

/* 37.feladat
 Írj programot, ami csak pozitív számot hajlandó beolvasni.*/

 const number = prompt("Írjon be egy számot: ");

if (number >= 0) {
    if (number == 0) {
        alert("A szám 0.");
    } else {
        alert("A szám pozitív.");
    }
} else {
    alert("Nem adhat meg negatív számot!");
}


/* 38.feladat
 írj programot, mely bekér két számot és eldönti mennyi a távolságuk a számegyenesen!*/

let szam = Number(windows.prompt("Add meg az első számot: "));
let szam2 = Number(windows.prompt("Add meg a második számot: "));
let tavolsag = szam - szam2;

alert("A két szám távolsága a számegyenesen:" + tavolsag);




/* 39.feladat
 írj programot, mely bekér két számot és kiszámolja mennyi az átlaguk! */

let number1 = Number(window.prompt("Adja meg az első számot: "));
let number2 = Number(window.prompt("Adja meg a második számot: "));
let atlag = (number1 + number2) / 2;
alert("A két szám átlaga: " +atlag.toFixed(1));



/* 40. feladat
 írj programot, mely addig kér számokat a billentyűzetről amig összegük kisebb mint 100!*/

let osszeg = a+b;

while (osszeg < 100) {
    let a = Number(window.propmt("Adj meg egy számot: "));
    let b = Number(windows.prompt("Adj meg egy másik számot: "));
    alert("A két szám összege:" + osszeg)
    if (a+b >= 100) {            
        break;
    } 
}