/* 31. feladat
Írj programot, mely beolvas három egész számot, és kiírja a képernyőre a legkisebbet!
*/
let elso_szam = Number(window.prompt("Add meg az első számot: "));
let masodik_szam = Number(window.prompt("Add meg a második számot: "));
let harmadik_szam = Number(window.prompt("Add meg a harmadik számot: "));


if (elso_szam <= masodik_szam && elso_szam <= harmadik_szam)
        alert(elso_szam+ " a legkisebb.");
 
    else if (masodik_szam <= elso_szam && masodik_szam <= harmadik_szam)
        alert( masodik_szam + " a legkisebb.");
 
    else
        alert( harmadik_szam + " a legkisebb.");
     

/* 32. feladat
Írj programot, ami beolvassa a háromszög oldalainak hosszát, és megmondja, hogy ilyen oldalakkal szerkeszthető-e háromszög!
*/
let szam_a = Number(window.prompt("Adja meg a háromszög 'a' oldalát:"));
let szam_b = Number(window.prompt("Adja meg a háromszög 'b' oldalát:"));
let szam_c = Number(window.prompt("Adja meg a háromszög 'c' oldalát:"));

if (szam_a < (szam_b + szam_c) && szam_b < (szam_a + szam_c) 
&& szam_c < (szam_a + szam_b)) 
{
    alert("A háromszög megszerkeszthető.")
} else
{
    alert("A háromszög nem megszerkeszthető.")
}



/* 33. feladat
Írj programot, mely beolvassa a másodfokú egyenlet együtthatóit, és kiírja, hogy az egyenletnek van-e megoldása!
*/

let root1, root2;

let a = prompt("Enter the first number: ");
let b = prompt("Enter the second number: ");
let c = prompt("Enter the third number: ");


let discriminant = b * b - 4 * a * c;


if (discriminant > 0) {
    root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
    root2 = (-b - Math.sqrt(discriminant)) / (2 * a);

 
    alert(`A másodfokú egyenlet megoldásai a következők ${root1} és ${root2}`);
}


else if (discriminant == 0) {
    root1 = root2 = -b / (2 * a);
    alert(`A másodfokú egyenlet megoldásai a következők ${root1} és ${root2}`);
}

else {
    let realPart = (-b / (2 * a)).toFixed(2);
    let imagPart = (Math.sqrt(-discriminant) / (2 * a)).toFixed(2);


    alert(
    `A másodfokú egyenlet megoldásai a következők ${realPart} + ${imagPart}i és ${realPart} - ${imagPart}i`
  );
}



/* 34. feladat
Írj programot, mely beolvassa egy derékszögű háromszög két befogóját, és megadja az átfogójának a hosszát! Az átfogót 2 tizedesjeggyel add meg!
*/

let befogo1 = Number(window.prompt("Adja meg a háromszög első befogóját: "))
let befogo2 = Number(window.prompt("Adja meg a háromszög második befogóját: "))

let h = (((befogo1 * befogo1) + (befogo2 * befogo2))**(1/2));

alert(h.toFixed(2));



/* 35. feladat
Írjon programot, mely kiírja a képernyőre a 1-10 ig a számok reciprokát!
*/

for(let qty = 1;qty <= 10;qty++){
    if (qty=>1/qty)
    console.log(qty);
   
}