/* 41. feladat
Írj programot, mely addig olvas be számokat a billentyűzetről, ameddig azok kisebbek, mint tíz. 
Írja ki ezek után a beolvasott számok összegét! */

let osszeg = a+b;

while (osszeg < 10) {
    let a = Number(window.propmt("Adj meg egy számot: "));
    let b = Number(windows.prompt("Adj meg egy másik számot: "));
    alert("A két szám összege:" + osszeg)
    if (a+b >= 100) {            
        break;
    } 
}


/* 42. feladat
Állítson elő 0-tól 100-ig véletlen számot és írja ki a képernyőre! */

function randomIntFromInterval(min, max) {  
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  
  const rndInt = randomIntFromInterval(0, 100)
  console.log(rndInt)

/* 43. feladat
Állítson elő 10-tól 50-ig véletlen számot és írja ki a képernyőre! */

function randomIntFromInterval(min, max) {  
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  
  const rndInt_1 = randomIntFromInterval(10, 50)
  console.log(rndInt_1)

/* 44. feladat
Állítson elő 132-tól 147-ig véletlen számot és írja ki a képernyőre! */

console.log("-------")
function randomIntFromInterval(min, max) { 
    return Math.floor(Math.random() * (max - min + 1) + min)
  }
  
  const rndInt_2 = randomIntFromInterval(132, 147)
  console.log(rndInt_2)

/* 45. feladat
Állítson elő 132-tól 148-ig véletlen számot, ami páros, és írja ki a képernyőre! */

function randomIntIntervallum(min, max) {
    var range = 100;
    var number = Math.floor( Math.random() * range / 2 ) * 2;
}

const randomInt = randomIntIntervallum(132,148) 
console.log(randomInt)