/* 21. feladat
Olvasd be egy négyzet oldalát, írd ki a kerületét, területét!*/

var a_oldal = Number(propmt("Add meg a négyzet 'a' oldalát: "))
var kerulet = 4* a_oldal;
var terulet = a_oldal * a_oldal;

alert("A négyzet kerülete: " + kerulet, "A négyzet területe: " + terulet);

/* 22. feladat
Olvasd be egy téglalap oldalait, írd ki a kerületét, területét!*/

var a_oldala = Number(propmt("Add meg a téglalap 'a' oldalát: "))
var b_oldala = Number(propmt("Add meg a téglalap 'b' oldalát: "))

var teglalap_kerulet = 2 * (a_oldala + b_oldala);
var teglalap_teruet = a_oldala * b_oldala;

alert("A téglalap kerülete: " + teglalap_kerulet);
alert("A téglalap területe: " + teglalap_terulet);

/* 23. feladat
Írjon programot, mely kiírja az első 10 db páros szám összegét a képernyőre!*/

console.log("----23.feladat----")
var total = 0;
    for(var i = 1; i <= 10; i++){
        total += i;
      }
      console.log(total);

/* 24. feladat
Írjon programot, mely kiírja a képernyőre a páratlan számokat 80-tól 20-ig. */

for (var i = 80; i >= 20; i--) {
    if (i % 2 != 0) {
        console.log(i)
    }
}

/* 25. feladat
Készítsen programot, mely beolvas 3 db számot a billentyűzetről, majd meghatározza a számok átlagát. */

console.log("Add meg az első számot: ")
console.log("Add meg a második számot: ")
console.log("Add meg a harmadik számot: ")
var atlag = (szam_1+szam_2+szam_3) / 3;
console.log("A három szám átlaga: ");
