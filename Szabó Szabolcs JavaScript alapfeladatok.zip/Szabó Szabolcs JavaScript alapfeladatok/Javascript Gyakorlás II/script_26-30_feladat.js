/* 26. feladat
Írjon programot, mely kiírja a képernyőre a páratlan számokat 1-től 90-ig. */

for (var j = 1; j <= 90; j++) {
    if (j % 2 != 0) {
        console.log(j)
    }
}

/* 27. feladat
Írjon programot, mely kiírja a képernyőre a páratlan számokat 60-tól 15-ig. */

console.log("----27. feladat----")
for (var k = 60; k>= 15; k-- ) {
    if (k % 2 !=0) {
        console.log(k)
    }
}

/* 28. feladat
Írjon programot, mely kiírja a képernyőre a páros számokat 70-tól 25-ig. */

var i = 70;

document.write("<br>28.feladat: Páros számok 70-től 25-ig");
while(i>=25)
{
document.write(i + "  ");
i = i - 2;
}

/* 29. feladat
Írj programot, mely beolvas egy pozitív egész számot, és kiírja az egész számokat egymás alá a képernyőre eddig a számig!*/

var szam = Number(prompt("Adj meg egy pozitív egész számot: "))


for (var l = 0; l <= szam; l++) {
    if (l <= szam) {
        document.write("<br>" + l)
    }
}

/* 30. feladat
Írj programot, mely beolvas két egész számot, és kiírja a képernyőre a nagyobbikat! */

var number = Number(prompt("Adj meg egy számot: "))
var number2 = Number(prompt("Adj meg egy másik számot: "))

if (number > number2) {
    alert("Az első szám a nyagobb.")
} else if (number < number2) {
    alert("A második szám a nagyobb.")
} else if (number = number2) {
    alert("A két szám egyenlő.")
}

