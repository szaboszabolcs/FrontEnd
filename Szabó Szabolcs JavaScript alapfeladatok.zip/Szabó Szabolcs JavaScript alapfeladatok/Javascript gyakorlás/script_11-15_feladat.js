/* 11. feladat
Írjon programot, mely kiírja a képernyőre az első tíz természetes számot!*/

console.log("----11.feladat-----")

for(let i=1 ; i<=10; i++) {
    console.log(i);
}

/*12. feladat
Alakítsa át az előző programot úgy, hogy az csak a páros számokat írja a képernyőre!*/

console.log("----12.feladat----")

for(let i=1 ; i<=10; i++) {
    if (i % 2 == 0){
        console.log(i);
    }
}

/* 13.feladat
Írjon programot, mely kiírja a képernyőre a hárommal osztható számokat 100-ig!*/

console.log("----13.feladat----")

for(let i=1 ; i<=100; i++) {
    if (i % 3 == 0){
        console.log(i);
    }
}

/* 14.feladat
Írj programot, ami beolvas egy számot, majd kiírja a kétszeresét!*/

var szam_beolvas = Number(prompt("Adj meg egy számot!"));
ketszeres = szam_beolvas * 2;
alert("A szám kétszerese: " + ketszeres);

/* 15.feladat
Írjon programot ami kiírja a képernyőre az első 5 egész szám összegét!*/

console.log("----15.feladat----")
var total = 0;
    for(var i = 1; i <= 5; i++){
        total += i;
      }
      console.log(total);