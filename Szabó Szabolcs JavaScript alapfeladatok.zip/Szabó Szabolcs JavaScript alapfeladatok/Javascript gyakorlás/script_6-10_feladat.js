// 6. feladat
//Kérjen be két egész számot a felhasználótól, és írja ki a két szám különbségét!//

var number1 = Number(prompt("Add meg az első számot: "))
var number2 = Number(prompt("Add meg a második számot: "))
var kulonbseg = number1 - number2;
alert("A két szám különbsége: " + kulonbseg);

/* 7. feladat
Kérjen be két egész számot a felhasználótól, és írja ki a két szám szorzatát!*/

var number3 = Number(prompt("Adj meg egy egész számot: "))
var number4 = Number(prompt("Adj meg egy másik egész számot: "))
szorzas = number3 * number4;
alert("A két szám szorzata: " + szorzas);

/* 8. feladat
Kérjen be két egész számot a felhasználótól, és írja ki a két szám hányadosát, a tizedes tört értékeket is megjelenítve!*/

var number5 = Number(prompt("Adj meg egy egész számot: "))
var number6 = Number(prompt("Adj meg egy másik egész számot: "))
osztas = number5 / number6;
alert("A két szám hányadosa: " + osztas);

/* 9. feladat
Írjon programot, mely elszámol 0-tól 100-ig!*/

console.log(".".length);
let max = "..........".length;

for(let qty = [].length;qty <= (max * max);qty++){
    console.log(qty);
}

console.log("-------------------------------------")

/* 10. feladat
Írjon programot, mely elszámol 100-tól 800-ig!*/

for(let qty = 100;qty <= 800;qty++){
    console.log(qty);
}
var userNo = 100;
while (userNo <= 800) {
 console.log(userNo);
 userNo++;
}