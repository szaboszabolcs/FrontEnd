/*1. feladat
Írj programot ami beolvassa a felhasználó nevét, majd köszön neki, a nevén szólítva őt!*/

let nev = prompt("Adja meg a felhasználó nevét!");
alert("Üdvözlöm " + nev + "!")

/*2. feladat
Állítsa elő a következő alakzatot!
************
oooooooooooo
*/

console.log("************");
console.log("oooooooooooo");

/*3. feladat
Állítsa elő a következő alakzatot!
*o*o*o*o*o*o
*o*o*o*o*o*o */

console.log("*o*o*o*o*o*o");
console.log("*o*o*o*o*o*o");

/* 4. feladat
Kérjen be két egész számot a felhasználótól, és írja ki a két szám összegét!*/

var szam1 = Number(prompt("Adja meg az első számot: "))
var szam2 = Number(prompt("Adja meg a második számot: "))
var osszeg = szam1 + szam2;
alert("A két szám összege: " + osszeg);


/* 5. feladat
Kérjen be három egész számot a felhasználótól, és írja ki a három szám összegét!*/

var szam3 = Number(prompt("Add meg az első számot: "))
var szam4 = Number(prompt("Add meg a második számot: "))
var szam5 = Number(prompt("Add meg a harmadik számot: "))
var osszesen = szam3 + szam4 + szam5;
alert("A három szám összege: " + osszesen);






