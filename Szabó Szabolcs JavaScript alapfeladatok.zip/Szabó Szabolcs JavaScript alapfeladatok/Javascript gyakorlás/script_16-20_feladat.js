/* 16.feladat
Készítsen programot, mely kiírja 1-10-ig a számok négyzetét.*/

document.write("16. feladat: számok négyzete");
  for(j = 1; j <= 10; j++)
  {
    document.write("<br> " + j + " -> " + j*j);
  }

/* 17. feladat
Készítsen programot, mely kiírja 1-től a számok négyzetét, amig az kisebb mint 1000.*/

document.write("<br>16. feladat: számok négyzete amíg az érték nem 1000</br>");
  for(k = 1; k*k <1000; k++)
  {
    document.write("<br> " + k + " -> " + k*k);
  }

/* 18. feladat
Írjon programot, mely kiírja a képernyőre a páros számokat 1-től 100-ig.*/

let m 
let a = 100
console.log("18. feladat: Páros számok kiiratása 1-től 100-ig.")
for (m=1;m<=a;m++)
{
  if(m%2==0){
    console.log(m)
  }
}

/* 19. feladat
Olvass be két számot, írd ki a négyzetüket!*/

let number_one = Number(prompt("Add meg az első számot: "));
let number_two = Number(prompt("Add meg a második számot: "))
square = number_one ** 2;
square_1 = number_two ** 2;
alert("Az első szám négyzete: " + square);
alert("A második szám négyzete:" + square_1);

/* 20. feladat
Írjon programot, mely kiírja a képernyőre a páros számokat 50-től 10-ig.*/

var i = 50;

document.write("<br>20.feladat: Páros számok 50-től 10-ig <br/>");
while(i>=10)
{
document.write(i + "  ");
i = i - 2;
}