// 1) Dobókocka

function dobokocka() {
    let dobas = Number(prompt("Hány kockával dobjunk?"));
    let szamok = "";

    for (let i = 1; i <= dobas; i++){
        random = Math.floor(Math.random()*6+1);
        //szamok = szamok + random + " ";
        szamok.push(random);
        
    }
    alert(szamok)
}
//dobokocka()


// 2) Összeadás
function osszeadas() {
    let darab = Number(prompt("Hány számot adjunk össze?"));
    let sum = 0;

    for (let i = 1; i <= darab; i++) {
        sum += Number(prompt("Add meg a(z) "+i+". számot:"));
    }

    alert(sum);
}

// 3) Faktoriális

function fak() {
    let szam = prompt("Adj meg egy számot:");

    if (szam === 0 || szam === 1) {
        alert("A faktoriális: 1");
    } else {
        for (let i = szam-1; i > 1; i--) {
            szam *= i;
        }
    }
    alert(`A faktoriális: ${szam}`);
}

fak();

// 4) Bingbang
function bingbang () {
    for (let i = 1; i < 100; i++) {
        if (i % 5 === 0 && i % 3 === 0){
            console.log("bingbang");
        } else if (i % 5 === 0) {
            console.log("bang");
        } else if (i % 3 === 0) {
            console.log("bing");
        } else {
            console.log(i)
        }
    }
}

bingbang(20);

// 5) Kő, papír, olló
function koPapirOllo () {
    let kez1 = prompt("Kő/papír/olló?").toLowerCase;

    let kezek = {
        kő: 1,
        papir: 2,
        olló: 3
    }
    let keztomb = ["kő","papir","olló"];
    let kez2 = Math.floor(Math.random()*3);
    alert("Nekem "+keztomb[kez2-1]);
    let index = keztomb.imdexOf(kez1)

    if (kezek[kez1] === kez2) {
        alert("Döntetlen");
    } else if ((index === 0 && kez2 === 2) || 
    (kezek[kez1] === 1 && kez2 === 0) ||
    (kezek[kez1] === 2 && kez2 === 1)) {
        alert("Nyertél!");
    } else {
        alert("Vesztettél!");
    }
}

koPapirOllo();