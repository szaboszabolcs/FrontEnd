function App () {
    const [getColor, setColor] = React.useState("green");
    return <div>
        App
        <BoxComponent szin={getColor}/>
        <ButtonComponent szin="green" getColor={getColor} setColor={setColor}/>
        <ButtonComponent szin="blue" getColor={getColor} setColor={setColor}/>
        <ButtonComponent szin="firebrick" getColor={getColor} setColor={setColor}/>

    </div>
}

function BoxComponent({szin})
{
    return <div
    style={{width: "200px",height: "200px", backgroundColor: szin,
    margin: "20px", padding: "20px"}}
    >
    </div>
}


function ButtonComponent({szin, getColor, setColor})
{
    return <button
    style={{backgroundColor: szin}}
    disabled={(getColor == szin)}
    onClick={() => {
        setColor(szin)
    }}
    >
    {szin}
    </button>
}

ReactDOM.render(<App/>, document.querySelector("#react-componens"));
